//! Site Grabber: explores a web site from a start page and collects the
//! files it links to (images, videos, music, archives, documents...).

use crate::http::SendOrdered;
use crate::config::wildcard_match;
use crate::filename;
use crate::http::request;
use crate::model::RequestHeaders;
use regex::Regex;
use reqwest::Client;
use std::collections::{HashSet, VecDeque};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use tokio_util::sync::CancellationToken;

#[derive(Debug, Clone)]
pub struct GrabOptions {
    pub start_url: String,
    /// levels of pages to explore below the start page (0 = start page only)
    pub depth: u32,
    /// explore pages of other sites too (one level)
    pub other_sites: bool,
    /// don't go above the start page's folder
    pub no_parent: bool,
    /// file types to collect; empty = every file that isn't a web page
    pub exts: Vec<String>,
    /// only addresses matching one of these (* allowed); empty = all
    pub include: Vec<String>,
    /// skip addresses matching any of these
    pub exclude: Vec<String>,
    /// stop after this many pages
    pub max_pages: usize,
    /// pages explored at the same time (1-10)
    pub parallel: usize,
    pub headers: RequestHeaders,
    pub user_agent: String,
}

#[derive(Debug, Clone, PartialEq)]
pub struct FoundFile {
    pub url: String,
    pub name: String,
    pub ext: String,
    /// the link's text (used as the description)
    pub text: String,
    /// page the link was found on
    pub page: String,
}

/// Live counters for the grabber window.
#[derive(Default)]
pub struct GrabProgress {
    pub pages_done: AtomicUsize,
    pub pages_queued: AtomicUsize,
    pub files: AtomicUsize,
    pub current: Mutex<String>,
}

const PAGE_EXTS: [&str; 13] =
    ["", "html", "htm", "php", "asp", "aspx", "jsp", "shtml", "cfm", "cgi", "pl", "xhtml", "phtml"];

pub fn is_page_ext(ext: &str) -> bool {
    PAGE_EXTS.contains(&ext)
}

fn anchor_re() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| {
        Regex::new(r#"(?is)<a\b[^>]*?\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))[^>]*>(.*?)</a\s*>"#).unwrap()
    })
}

fn attr_re() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| {
        Regex::new(r#"(?i)\b(?:src|href|data-src|data-href|poster)\s*=\s*(?:"([^"]*)"|'([^']*)')"#).unwrap()
    })
}

fn tag_re() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| Regex::new(r"(?s)<[^>]*>").unwrap())
}

fn decode_entities(s: &str) -> String {
    s.replace("&amp;", "&")
        .replace("&#38;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&nbsp;", " ")
}

/// Every link of an HTML page as (absolute address, link text).
pub fn extract_links(html: &str, base: &str) -> Vec<(String, String)> {
    let Ok(base) = url::Url::parse(base) else { return Vec::new() };
    let mut seen = HashSet::new();
    let mut out = Vec::new();
    let mut push = |raw: &str, text: String| {
        let raw = decode_entities(raw.trim());
        if raw.is_empty()
            || raw.starts_with('#')
            || ["javascript:", "mailto:", "data:", "tel:", "about:"]
                .iter()
                .any(|p| raw.to_ascii_lowercase().starts_with(p))
        {
            return;
        }
        let Ok(mut u) = base.join(&raw) else { return };
        if !matches!(u.scheme(), "http" | "https") {
            return;
        }
        u.set_fragment(None);
        let s = u.to_string();
        if seen.insert(s.clone()) {
            out.push((s, text));
        }
    };
    for c in anchor_re().captures_iter(html) {
        let href = c.get(1).or(c.get(2)).or(c.get(3)).map(|m| m.as_str()).unwrap_or("");
        let text = c.get(4).map(|m| tag_re().replace_all(m.as_str(), " ").to_string()).unwrap_or_default();
        let text = decode_entities(&text).split_whitespace().collect::<Vec<_>>().join(" ");
        push(href, text);
    }
    for c in attr_re().captures_iter(html) {
        let v = c.get(1).or(c.get(2)).map(|m| m.as_str()).unwrap_or("");
        push(v, String::new());
    }
    // addresses written as text (lists of links in a post, a note, JSON in
    // a script): many pages have their file links only like that
    for m in text_url_re().find_iter(html) {
        let u = m.as_str().trim_end_matches(['.', ',', ';', ':', '!', '?', '\\']);
        // written inside JSON: "\/" is "/", "\u0026" is "&"
        push(&u.replace("\\/", "/").replace("\\u0026", "&"), String::new());
    }
    out
}

fn text_url_re() -> &'static regex::Regex {
    static RE: std::sync::OnceLock<regex::Regex> = std::sync::OnceLock::new();
    RE.get_or_init(|| regex::Regex::new(r#"https?:(?:\\?/){2}[^\s"'<>()\[\]{}|^`]+"#).unwrap())
}

fn ext_of(u: &url::Url) -> String {
    let last = u.path_segments().and_then(|mut s| s.next_back()).unwrap_or("");
    let last = percent_encoding::percent_decode_str(last).decode_utf8_lossy().to_string();
    filename::extension(&last)
}

fn wanted_ext(opts: &GrabOptions, ext: &str) -> bool {
    if opts.exts.is_empty() {
        return !is_page_ext(ext);
    }
    opts.exts.iter().any(|e| wildcard_match(e.trim_start_matches('.'), ext))
}

fn allowed(opts: &GrabOptions, url: &str) -> bool {
    if opts.exclude.iter().any(|p| !p.is_empty() && wildcard_match(p, url)) {
        return false;
    }
    opts.include.iter().all(|p| p.is_empty()) || opts.include.iter().any(|p| !p.is_empty() && wildcard_match(p, url))
}

/// What an address gave: a page to read, or a file (its name from the server).
enum Fetched {
    Page(String, String),
    File { url: String, name: String },
}

/// The name a file answer gives itself (the server's, else its address's).
fn answer_name(resp: &reqwest::Response) -> String {
    resp.headers()
        .get(reqwest::header::CONTENT_DISPOSITION)
        .and_then(|v| v.to_str().ok())
        .and_then(filename::from_content_disposition)
        .or_else(|| filename::from_url(resp.url().as_str()))
        .map(|n| filename::sanitize(&n))
        .filter(|n| !n.is_empty())
        .unwrap_or_else(|| "download".into())
}

fn is_page_type(ct: &str) -> bool {
    ct.is_empty() || ct.contains("html") || ct.contains("xml")
}

async fn fetch_page(client: &Client, url: &str, opts: &GrabOptions) -> Option<Fetched> {
    let resp = request(client, url, &opts.headers, &opts.user_agent).send_ordered().await.ok()?;
    if !resp.status().is_success() {
        return None;
    }
    let ct = resp
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_ascii_lowercase();
    let attached = resp
        .headers()
        .get(reqwest::header::CONTENT_DISPOSITION)
        .and_then(|v| v.to_str().ok())
        .is_some_and(|v| v.to_ascii_lowercase().contains("attachment"));
    // an address with no file name of its own ("get.php?id=5", "/file/abc")
    // that answers with a file: a file (only its first bytes were read)
    if attached || !is_page_type(&ct) {
        // no extension in the name: the one of its type ("77" + application/pdf)
        let name = filename::ensure_extension(answer_name(&resp), Some(&ct));
        return Some(Fetched::File { url: resp.url().to_string(), name });
    }
    let final_url = resp.url().to_string();
    // read at most 4 MB of a page
    let mut resp = resp;
    let mut body = Vec::new();
    while let Some(chunk) = resp.chunk().await.ok()? {
        body.extend_from_slice(&chunk);
        if body.len() > 4 * 1024 * 1024 {
            break;
        }
    }
    Some(Fetched::Page(final_url, String::from_utf8_lossy(&body).into_owned()))
}

/// What a link turned out to be when the server was asked.
#[derive(Debug, Clone, PartialEq)]
pub enum Checked {
    /// a file: the server's name for it and its size
    File { name: String, size: Option<u64> },
    /// a web page
    Page,
    /// no good (not found, refused...): why, in short
    Gone(String),
}

/// Ask the server what a link is, without downloading it.
pub async fn check_link(client: &Client, url: &str, headers: &RequestHeaders, ua: &str) -> Checked {
    let asked = tokio::time::timeout(std::time::Duration::from_secs(20), crate::http::probe_quick(client, url, headers, ua)).await;
    crate::http::drop_kept(url);
    match asked {
        Ok(Ok(p)) => {
            let ct = p.content_type.clone().unwrap_or_default().to_ascii_lowercase();
            if (ct.contains("html") || ct.contains("xhtml")) && p.kind == crate::model::DownloadKind::Http {
                Checked::Page
            } else {
                Checked::File { name: p.file_name.clone(), size: p.total_size }
            }
        }
        Ok(Err(e)) => Checked::Gone(format!("{e:#}").chars().take(120).collect()),
        Err(_) => Checked::Gone("no answer".into()),
    }
}

/// Worth asking the server about: an address that names no file but looks
/// like a download ("download.php?id=5", "/get/123", "?dl=1").
pub fn looks_like_download(url: &str, text: &str) -> bool {
    let l = url.to_ascii_lowercase();
    let t = text.to_lowercase();
    let words = ["download", "/dl/", "dl=", "/get/", "get.php", "file", "attachment", "/d/", "mirror", "fetch"];
    words.iter().any(|w| l.contains(w)) || ["download", "تحميل", "تنزيل"].iter().any(|w| t.contains(w))
}

/// Links beyond the levels to explore that are asked whether they are files.
const MAX_ASKED: usize = 300;

/// Explore the site and return the files found (in the order found).
pub async fn crawl(
    client: Client,
    opts: GrabOptions,
    progress: Arc<GrabProgress>,
    cancel: CancellationToken,
    on_file: impl Fn(FoundFile) + Send + Sync + 'static,
) -> Vec<FoundFile> {
    let Ok(start) = url::Url::parse(&opts.start_url) else { return Vec::new() };
    let start_host = start.host_str().unwrap_or("").to_ascii_lowercase();
    let start_dir = {
        let p = start.path();
        p[..p.rfind('/').map(|i| i + 1).unwrap_or(p.len())].to_string()
    };
    let on_file = Arc::new(on_file);
    let mut found: Vec<FoundFile> = Vec::new();
    let mut seen_files: HashSet<String> = HashSet::new();
    let mut seen_pages: HashSet<String> = HashSet::new();
    // (url, level, on another site, only to see whether it is a file)
    let mut queue: VecDeque<(String, u32, bool, bool)> = VecDeque::new();
    queue.push_back((opts.start_url.clone(), 0, false, false));
    let mut asked = 0usize;
    seen_pages.insert(opts.start_url.clone());
    progress.pages_queued.store(1, Ordering::Relaxed);
    let parallel = opts.parallel.clamp(1, 10);

    while !queue.is_empty() && !cancel.is_cancelled() {
        let mut batch = Vec::new();
        while batch.len() < parallel {
            match queue.pop_front() {
                Some(item) => batch.push(item),
                None => break,
            }
        }
        let mut tasks = tokio::task::JoinSet::new();
        for (url, level, foreign, only_ask) in batch {
            let client = client.clone();
            let opts2 = opts.clone();
            if let Ok(mut c) = progress.current.lock() {
                *c = url.clone();
            }
            tasks.spawn(async move {
                let page = fetch_page(&client, &url, &opts2).await;
                (url, level, foreign, only_ask, page)
            });
        }
        while let Some(res) = tokio::select! {
            r = tasks.join_next() => r,
            _ = cancel.cancelled() => None,
        } {
            let Ok((url, level, foreign, only_ask, page)) = res else { continue };
            progress.pages_done.fetch_add(1, Ordering::Relaxed);
            let (page_url, html) = match page {
                Some(Fetched::Page(u, h)) if !only_ask => (u, h),
                Some(Fetched::File { url: file_url, name }) => {
                    let ext = filename::extension(&name);
                    let new = seen_files.insert(url.clone()) | seen_files.insert(file_url.clone());
                    if wanted_ext(&opts, &ext) && new {
                        let f = FoundFile { url: url.clone(), name, ext, text: String::new(), page: url.clone() };
                        progress.files.fetch_add(1, Ordering::Relaxed);
                        on_file(f.clone());
                        found.push(f);
                    }
                    continue;
                }
                _ => continue,
            };
            for (link, text) in extract_links(&html, &page_url) {
                let Ok(u) = url::Url::parse(&link) else { continue };
                let host = u.host_str().unwrap_or("").to_ascii_lowercase();
                let ext = ext_of(&u);
                if !allowed(&opts, &link) {
                    continue;
                }
                if is_page_ext(&ext) && (opts.exts.is_empty() || !wanted_ext(&opts, &ext)) {
                    // a page: explore it later if it's within the limits
                    let same = host == start_host;
                    let next_level = level + 1;
                    let ok_site = same || (opts.other_sites && !foreign);
                    let ok_parent = !opts.no_parent || !same || u.path().starts_with(&start_dir);
                    if next_level <= opts.depth
                        && ok_site
                        && ok_parent
                        && seen_pages.len() < opts.max_pages.max(1)
                        && seen_pages.insert(link.clone())
                    {
                        queue.push_back((link, next_level, !same, false));
                        progress.pages_queued.fetch_add(1, Ordering::Relaxed);
                    } else if asked < MAX_ASKED && looks_like_download(&link, &text) && seen_pages.insert(link.clone()) {
                        // too deep to explore, but it may be a file: only asked
                        asked += 1;
                        queue.push_back((link, next_level, !same, true));
                        progress.pages_queued.fetch_add(1, Ordering::Relaxed);
                    }
                    continue;
                }
                if wanted_ext(&opts, &ext) && seen_files.insert(link.clone()) {
                    let name = filename::from_url(&link).unwrap_or_else(|| "download".into());
                    let f = FoundFile { url: link, name, ext, text: text.clone(), page: url.clone() };
                    progress.files.fetch_add(1, Ordering::Relaxed);
                    on_file(f.clone());
                    found.push(f);
                }
            }
        }
    }
    found
}

/// File types of the grabber's ready-made filters.
pub fn template_exts(template: i32) -> Vec<String> {
    let list = match template {
        // all images
        1 => "jpg jpeg png gif webp bmp svg tif tiff ico heic",
        // all videos
        2 => "mp4 mkv avi mov wmv flv webm m4v ts 3gp mpg mpeg",
        // all music
        3 => "mp3 wav flac aac ogg m4a wma opus",
        // archives + programs
        4 => "zip rar 7z tar gz tgz bz2 xz iso exe msi apk dmg",
        // documents
        5 => "pdf doc docx xls xlsx ppt pptx txt epub",
        // every file
        _ => "",
    };
    list.split_whitespace().map(String::from).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn links_written_as_text() {
        let html = r#"<pre>Mirror 1: https://files.example/part1.rar, and https://files.example/part2.rar.</pre>
            <script>var u = "https:\/\/cdn.example\/v.mp4"; var w = "https:\/\/cdn.example\/get?id=1\u0026t=2";</script>"#;
        let links: Vec<String> = extract_links(html, "https://site/").into_iter().map(|(u, _)| u).collect();
        assert!(links.contains(&"https://files.example/part1.rar".to_string()), "{links:?}");
        assert!(links.contains(&"https://files.example/part2.rar".to_string()), "{links:?}");
        assert!(links.contains(&"https://cdn.example/v.mp4".to_string()), "{links:?}");
        assert!(links.contains(&"https://cdn.example/get?id=1&t=2".to_string()), "{links:?}");
    }

    #[test]
    fn links_from_html() {
        let html = r##"<html><body>
            <a href="files/a.pdf">Document <b>A</b></a>
            <a href='/b.pdf?x=1&amp;y=2'>B</a>
            <a href="#top">top</a> <a href="mailto:x@y.z">mail</a>
            <img src="//cdn.example.com/p.png"> <a href=page2.html>next</a>
        </body></html>"##;
        let l = extract_links(html, "https://example.com/dir/index.html");
        let urls: Vec<&str> = l.iter().map(|(u, _)| u.as_str()).collect();
        assert!(urls.contains(&"https://example.com/dir/files/a.pdf"));
        assert!(urls.contains(&"https://example.com/b.pdf?x=1&y=2"));
        assert!(urls.contains(&"https://cdn.example.com/p.png"));
        assert!(urls.contains(&"https://example.com/dir/page2.html"));
        assert!(!urls.iter().any(|u| u.contains("mailto") || u.ends_with("#top")));
        assert_eq!(l.iter().find(|(u, _)| u.ends_with("a.pdf")).unwrap().1, "Document A");
    }
}
