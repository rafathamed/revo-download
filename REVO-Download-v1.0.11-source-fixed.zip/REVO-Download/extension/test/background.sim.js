// Runs background.js with a fake `chrome` API and a fake REVO app.
// node extension/test/background.sim.js
const fs = require("fs"), path = require("path"), vm = require("vm"), assert = require("assert");
const dir = path.join(__dirname, "..");
const listeners = {}; const all = {}; const on = (n) => ({ addListener: (f) => { (all[n] = all[n] || []).push(f); listeners[n] = f; } });
const session = {}; const localStore = {}; let reloads = 0; let pingExt = null; const sent = []; const tabMsgs = []; let tabUrl = "https://www.youtube.com/watch?v=AAAAAAAAAAA";
const chrome = {
  storage: {
    onChanged: on("store"),
    local: { get: async (d) => (typeof d === "string" ? (d in localStore ? { [d]: localStore[d] } : {}) : { ...d, ...localStore }), set: async (o) => Object.assign(localStore, o) },
    session: {
      get: async (k) => { const ks = Array.isArray(k) ? k : [k]; const o = {}; for (const x of ks) if (x in session) o[x] = JSON.parse(JSON.stringify(session[x])); return o; },
      set: async (o) => Object.assign(session, JSON.parse(JSON.stringify(o))),
      remove: async (k) => { for (const x of [].concat(k)) delete session[x]; },
    },
  },
  downloads: { onCreated: on("dl"), onDeterminingFilename: on("det"), cancel: async (id) => { cancelled.push(id); }, erase: async () => {}, download: (o) => browserDl.push(o.url),
               search: async () => [], removeFile: async () => {} },
  webRequest: { onHeadersReceived: on("headers"), onBeforeRequest: on("before"), onBeforeSendHeaders: on("beforeSend"), onSendHeaders: on("sendHeaders") },
  tabs: { onUpdated: on("upd"), onRemoved: on("rm"), onCreated: on("tabNew"), get: async (id) => ({ id, url: tabUrl }), query: async () => [{ id: 7 }], remove: async () => {},
          sendMessage: async (id, m) => tabMsgs.push(m) },
  action: { setBadgeBackgroundColor: () => {}, setBadgeText: async () => {} },
  runtime: { onInstalled: on("inst"), onStartup: on("start"), onMessage: on("msg"), getManifest: () => ({ version: "1.0.4" }), reload: () => { reloads++; }, getURL: (p) => "chrome-extension://sim/" + p },
  contextMenus: { removeAll: () => {}, create: () => {}, onClicked: on("ctx") },
  cookies: { getAll: async (q) => (q.storeId === "1" ? [{ name: "private", value: "yes" }] : []), getAllCookieStores: async () => [{ id: "0", tabIds: [7] }, { id: "1", tabIds: [9] }] },
};
const ytCalls = []; const browserDl = []; const cancelled = []; const suggested = []; let appDown = false;
const fetch = async (url, opts = {}) => {
  // the program's key and real port, from the program's folder
  if (url === "chrome-extension://sim/token.json") return { ok: true, status: 200, json: async () => ({ token: "k".repeat(64), port: 47000 }) };
  if (url.startsWith("chrome-extension://sim/")) return { ok: true, status: 200, text: async () => "file" };
  if (url.endsWith("/ping") && pingExt) return { ok: true, status: 200, json: async () => ({ ext: pingExt }) };
  if (url.endsWith("/add")) { if (appDown) throw new TypeError("Failed to fetch"); sent.push(JSON.parse(opts.body)); }
  if (url.endsWith("/resolve") && JSON.parse(opts.body).url.includes("unsupported.example")) {
    return { ok: true, status: 200, json: async () => ({ ok: false, error: "Unsupported URL: https://unsupported.example/watch" }) };
  }
  if (url.endsWith("/resolve")) {
    ytCalls.push(JSON.parse(opts.body));
    await new Promise((r) => setTimeout(r, 30)); // yt-dlp takes a moment
    return { ok: true, status: 200, json: async () => ({ ok: true, title: "Real: Title", options: [
      { key: "1080p|MP4", label: "1080p · MP4", sub: "94 MB", quality: "1080p", videoUrl: "https://gv/137", audioUrl: "https://gv/140", ext: "mp4", size: 94e6, headers: [["User-Agent", "YtDlpUA"]] },
      { key: "audio|M4A", label: "Audio only · M4A 130k", sub: "4 MB", quality: "audio", videoUrl: "https://gv/140", audioUrl: null, ext: "m4a", size: 4e6, headers: [] } ] }) };
  }
  if (url.includes("/pl/master")) {
    return { ok: true, status: 200, text: async () => "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=640x360\n360/index.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=5000000,RESOLUTION=1920x1080\n1080/index.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=2500000,RESOLUTION=1280x720\nhttps://cdn2.example/720/index.m3u8\n" };
  }
  if (url.includes("/pl/") && url.endsWith("index.m3u8")) {
    return { ok: true, status: 200, text: async () => "#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6,\na.ts\n" };
  }
  return { ok: true, status: 200 };
};
const ctx = { chrome, fetch, AbortController, TextEncoder, TextDecoder, URLSearchParams, btoa, crypto: globalThis.crypto, setTimeout, clearTimeout, navigator: { userAgent: "TestUA" }, console, URL,
  importScripts: (...f) => f.forEach((x) => vm.runInContext(fs.readFileSync(path.join(dir, x), "utf8"), ctx)) };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(dir, "background.js"), "utf8"), ctx);

const gv = (itag, mime, clen, dur, r) => `https://rr1---sn-x.googlevideo.com/videoplayback?expire=9&itag=${itag}&mime=${encodeURIComponent(mime)}&clen=${clen}&dur=${dur}&pot=T&range=${r}&rn=1`;
const tick = () => new Promise((r) => setTimeout(r, 20));

(async () => {
  // player loads an ad, then the real video in many pieces
  listeners.before({ tabId: 7, url: gv(136, "video/mp4", 5e6, "15.0", "0-1000") });
  await tick();
  for (const r of ["0-1000", "1001-2000", "2001-3000"]) {
    listeners.before({ tabId: 7, url: gv(137, "video/mp4", 150e6, "300.5", r) }); await tick();
    listeners.before({ tabId: 7, url: gv(140, "audio/mp4", 4e6, "300.5", r) }); await tick();
  }
  const last = tabMsgs[tabMsgs.length - 1];
  assert.strictEqual(last.type, "revo-media");
  assert.strictEqual(last.items[0].label, "1080p Full HD · MP4");
  assert.strictEqual(last.items[0].yt.tag, "Full HD");
  console.log("button shows:", last.items.map((i) => i.label).join(" | "));

  // user clicks 1080p on the page
  const res = await new Promise((resolve) =>
    listeners.msg({ type: "revo-download", item: last.items[0], title: "(2) Cool video - YouTube" }, { tab: { id: 7, url: tabUrl } }, resolve));
  assert.strictEqual(res.ok, true);
  const req = sent[0];
  assert(req.url.includes("itag=137") && !req.url.includes("range="));
  assert(req.audioUrl.includes("itag=140"));
  assert.strictEqual(req.fileName, "Cool video [1080p].mp4");
  assert.strictEqual(req.userAgent, "TestUA");
  console.log("sent to app:", req.fileName, "| audio:", !!req.audioUrl);

  // navigating to another video clears the list
  tabUrl = "https://www.youtube.com/watch?v=BBBBBBBBBBB";
  await listeners.upd(7, { url: tabUrl }, { id: 7, url: tabUrl }); await tick();
  const afterNav = tabMsgs[tabMsgs.length - 1].items;
  assert(!afterNav.some((i) => i.label === "1080p · MP4" && i.yt && i.yt.videoUrl.includes("itag=137")), "old video's items gone");

  // ---- SABR video: no usable stream URL, the app (yt-dlp) gives the qualities
  listeners.before({ tabId: 7, url: "https://rr1---sn-x.googlevideo.com/videoplayback?expire=9&sabr=1&ump=1" });
  await listeners.upd(7, { url: tabUrl, status: "complete" }, { id: 7, url: tabUrl });
  await new Promise((r) => setTimeout(r, 150));
  assert.strictEqual(ytCalls.length, 1, "asked the app once");
  assert.strictEqual(ytCalls[0].url, "https://www.youtube.com/watch?v=BBBBBBBBBBB");
  assert(Array.isArray(ytCalls[0].cookieList), "sends the site's cookies as a list");
  const labels = tabMsgs.map((m) => (m.items[0] || {}).label);
  assert(labels.includes("Getting video qualities…"), "shows progress while resolving");
  const final = tabMsgs[tabMsgs.length - 1].items;
  assert.strictEqual(final[0].label, "1080p · MP4");
  const res2 = await new Promise((resolve) =>
    listeners.msg({ type: "revo-download", item: final[0], title: "ignored - YouTube" }, { tab: { id: 7, url: tabUrl } }, resolve));
  assert.strictEqual(res2.ok, true);
  const req2 = sent[sent.length - 1];
  assert.strictEqual(req2.fileName, "Real_ Title [1080p].mp4");
  assert.strictEqual(req2.sourcePage, "https://www.youtube.com/watch?v=BBBBBBBBBBB");
  assert.strictEqual(req2.sourceKey, "1080p|MP4");
  assert.strictEqual(req2.audioUrl, "https://gv/140");
  assert.strictEqual(req2.headers[0][1], "YtDlpUA");
  console.log("SABR video via app:", req2.fileName, "| key:", req2.sourceKey);

  // ---- any other site: a reel in an Instagram feed
  tabUrl = "https://www.instagram.com/";
  await listeners.upd(8, { url: tabUrl, status: "loading" }, { id: 8, url: tabUrl });
  tabMsgs.length = 0;
  listeners.msg({ type: "revo-video-seen", page: "https://www.instagram.com/reel/C1abcDEF/" }, { tab: { id: 8, url: tabUrl } }, () => {});
  await new Promise((r) => setTimeout(r, 150));
  const igCall = ytCalls[ytCalls.length - 1];
  assert.strictEqual(igCall.url, "https://www.instagram.com/reel/C1abcDEF/");
  const igItems = tabMsgs[tabMsgs.length - 1].items;
  assert.strictEqual(igItems[0].label, "1080p · MP4");
  const res3 = await new Promise((resolve) =>
    listeners.msg({ type: "revo-download", item: igItems[0], title: "x" }, { tab: { id: 8, url: tabUrl } }, resolve));
  assert.strictEqual(res3.ok, true);
  const req3 = sent[sent.length - 1];
  assert.strictEqual(req3.sourcePage, "https://www.instagram.com/reel/C1abcDEF/");
  assert.strictEqual(req3.referrer, "https://www.instagram.com/reel/C1abcDEF/");
  console.log("Instagram reel via app:", req3.fileName);
  // browser downloads: only new ones, each once, no loop when the app fails
  const now = new Date().toISOString();
  // Chrome style: decided before "Save as" (the browser waits for suggest)
  const dl = async (o) => {
    const item = { id: Math.random(), state: "in_progress", startTime: now, ...o };
    await listeners.dl(item); // nothing happens here any more
    const waits = listeners.det(item, () => suggested.push(item.id));
    assert.strictEqual(waits, true, "the browser waits for our answer");
    for (let i = 0; i < 20; i++) await tick();
    const kept = suggested.includes(item.id), taken = cancelled.includes(item.id);
    assert(kept !== taken, "answered exactly once: left to the browser or taken by the app");
  };
  let before = sent.length;
  await dl({ url: "https://example.com/old.pdf", startTime: new Date(Date.now() - 3600e3).toISOString() });
  await dl({ url: "https://example.com/done.pdf", state: "complete" });
  await dl({ url: "https://example.com/ext.pdf", byExtensionId: "other" });
  assert.strictEqual(sent.length, before, "restored / finished / extension downloads are left alone");
  await dl({ url: "https://example.com/new.pdf" });
  await dl({ url: "https://example.com/new.pdf" });
  assert.strictEqual(sent.length, before + 1, "a new download goes to the app once");
  appDown = true;
  {
    const n = cancelled.length;
    await dl({ url: "https://example.com/fail.pdf" });
    assert.strictEqual(cancelled.length, n, "the app did not take it: the browser's own download goes on");
    assert.deepStrictEqual(browserDl, [], "never asked for a second time");
    assert.strictEqual(localStore.lastLeft.why, "not-running", "why it stayed is kept for the toolbar window");
  }
  appDown = false;
  console.log("browser downloads: restored ones ignored, no repeats, no loop");
  // a form's download: sent with what the form sent; one with a file in it stays
  {
    const url = "https://forms.example/export";
    for (const f of all.before) f({ method: "POST", url, requestId: "r1", type: "main_frame", requestBody: { formData: { id: ["7"], name: ["a b"] } } });
    for (const f of all.beforeSend) f({ method: "POST", url, requestId: "r1", requestHeaders: [{ name: "Content-Type", value: "application/x-www-form-urlencoded" }] });
    const n = sent.length;
    await dl({ url, finalUrl: "https://files.example/report.csv", filename: "C:\\x\\report.csv" });
    const req = sent[n];
    assert(req, "the form's download went to the app");
    assert.strictEqual(req.url, url, "from the form's own address");
    assert.strictEqual(Buffer.from(req.post, "base64").toString(), "id=7&name=a+b");
    assert.strictEqual(req.postType, "application/x-www-form-urlencoded");
    const up = "https://forms.example/upload";
    for (const f of all.before) f({ method: "POST", url: up, requestId: "r2", type: "main_frame", requestBody: { formData: { f: ["x"] } } });
    for (const f of all.beforeSend) f({ method: "POST", url: up, requestId: "r2", requestHeaders: [{ name: "Content-Type", value: "multipart/form-data; boundary=x" }] });
    await dl({ url: up, filename: "C:\\x\\out.zip" });
    assert.strictEqual(sent.length, n + 1, "a form with a file in it stays in the browser");
    assert.strictEqual(localStore.lastLeft.why, "form");
    console.log("forms: the app posts the same data; an upload form stays in the browser");
  }
  // a private window: its own cookies go along
  {
    const n = sent.length;
    await dl({ url: "https://example.com/private.zip", incognito: true });
    assert.strictEqual(sent[n].cookies, "private=yes", "the private window's cookies");
    console.log("private window: its own cookies");
  }
  // add-in reloads itself once when the program brings a newer one
  pingExt = "1.0.5"; delete session.versionCheckAt;
  await ctx.followAppVersion(); await tick();
  assert.strictEqual(reloads, 1, "reloads for the new version");
  delete session.versionCheckAt;
  await ctx.followAppVersion(); await tick();
  assert.strictEqual(reloads, 1, "only once per version");
  pingExt = "1.0.4"; delete session.versionCheckAt;
  await ctx.followAppVersion();
  assert.strictEqual(reloads, 1, "same version: nothing");
  pingExt = null;
  console.log("self update: reloads once when the program has a newer add-in");
  // a player inside a frame (Dailymotion's "geo.dailymotion.com/player/…"):
  // the page around it is looked up, its qualities are offered
  {
    const page = "https://www.dailymotion.com/video/xac78kk";
    const n = ytCalls.length;
    const res = await new Promise((resolve) =>
      listeners.msg({ type: "revo-resolve-video", page: "", src: "", frame: true }, { tab: { id: 21, url: page }, frameId: 4 }, resolve));
    assert(res.items && res.items.length >= 2, "qualities of the page: " + JSON.stringify(res));
    assert.strictEqual(ytCalls[n].url, page, "the page, not the player frame");
    assert(!ytCalls.slice(n).some((c) => /geo\.dailymotion\.com/.test(c.url)));
    console.log("player in a frame: uses the page's qualities");
  }
  // the on / off switch of the add-in's window
  {
    localStore.enabled = false;
    listeners.store({ enabled: { newValue: false } }, "local");
    const before = sent.length;
    await dl({ url: "https://example.com/while-off.zip" });
    assert.strictEqual(sent.length, before, "off: the browser keeps its downloads");
    const cfg = await new Promise((r) => listeners.msg({ type: "revo-config" }, { tab: { id: 7, url: tabUrl } }, r));
    assert.strictEqual(cfg.enabled, false, "off: no buttons on videos");
    const n = tabMsgs.length;
    await ctx.pushToTab(7);
    assert.strictEqual(tabMsgs.slice(n).pop().items.length, 0, "off: nothing offered on the page");
    localStore.enabled = true;
    await dl({ url: "https://example.com/while-on.zip" });
    assert.strictEqual(sent.length, before + 1, "on again: back to the app");
    console.log("on / off switch: off leaves everything to the browser");
  }
  // a DASH stream (.mpd): offered, its qualities come from the app
  {
    listeners.headers({ tabId: 31, url: "https://cdn.example/v/manifest.mpd", statusCode: 200, responseHeaders: [{ name: "Content-Type", value: "application/dash+xml" }] });
    await tick(); await tick();
    const items = await new Promise((r) => listeners.msg({ type: "revo-get-media", tabId: 31 }, {}, r));
    const dash = items.find((i) => i.resolve);
    assert(dash && dash.resolve.endsWith(".mpd"), "DASH stream offered: " + JSON.stringify(items));
    const n = ytCalls.length;
    const res = await new Promise((r) => listeners.msg({ type: "revo-resolve-video", resolve: dash.resolve }, { tab: { id: 31, url: "https://site.example/watch/1" } }, r));
    assert(res.items && res.items.length, "its qualities");
    assert.strictEqual(ytCalls[n].url, dash.resolve);
    assert.strictEqual(ytCalls[n].referer, "https://site.example/watch/1", "the page goes along as referrer");
    console.log("DASH stream: offered, qualities from the app with the page as referrer");
  }
  // an HLS stream with several qualities: each one by its name (from the
  // playlist), the lists the player opened itself are not repeated
  {
    const hdr = [{ name: "Content-Type", value: "application/vnd.apple.mpegurl" }];
    listeners.headers({ tabId: 41, url: "https://cdn.example/pl/master", statusCode: 200, responseHeaders: hdr });
    await tick(); await tick(); await tick();
    listeners.headers({ tabId: 41, url: "https://cdn.example/pl/1080/index.m3u8", statusCode: 200, responseHeaders: hdr });
    for (let i = 0; i < 6; i++) await tick();
    const items = await new Promise((r) => listeners.msg({ type: "revo-get-media", tabId: 41 }, {}, r));
    const labels = items.map((i) => i.label);
    assert.strictEqual(JSON.stringify(labels), JSON.stringify(["1080p · MP4 · stream", "720p · MP4 · stream", "360p · MP4 · stream"]));
    assert.strictEqual(items[0].url, "https://cdn.example/pl/1080/index.m3u8");
    assert.strictEqual(items[1].url, "https://cdn2.example/720/index.m3u8");
    // the button of that player: the page is nothing the app knows -> its streams
    const res = await new Promise((r) =>
      listeners.msg({ type: "revo-resolve-video", page: "", src: "", frame: false }, { tab: { id: 41, url: "https://unsupported.example/watch" } }, r));
    assert(res.items && res.items.length === 3, "the streams instead of an error: " + JSON.stringify(res));
    console.log("HLS qualities:", labels.join(" | "));
  }
  console.log("background simulation: all checks passed");
})().catch((e) => { console.error(e); process.exit(1); });
